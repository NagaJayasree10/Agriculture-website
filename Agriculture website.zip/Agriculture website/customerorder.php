<?php
// PHP program to pop an alert
// message box on the screen
  
// Display the alert box 
echo '<script>alert("The order is placed successfully")</script>';
echo '<script>alert("The Details sends to farmer")</script>';
echo("<script>windows: location='customerhome.html'</script>");  
?>